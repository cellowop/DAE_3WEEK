import { SlidersHorizontal } from 'lucide-react';

interface FilterSidebarProps {
  selectedType: string;
  setSelectedType: (type: string) => void;
  selectedFuelType: string;
  setSelectedFuelType: (fuel: string) => void;
  selectedBrand: string;
  setSelectedBrand: (brand: string) => void;
  priceRange: [number, number];
  setPriceRange: (range: [number, number]) => void;
}

export function FilterSidebar({
  selectedType,
  setSelectedType,
  selectedFuelType,
  setSelectedFuelType,
  selectedBrand,
  setSelectedBrand,
  priceRange,
  setPriceRange,
}: FilterSidebarProps) {
  const carTypes = ['All', 'Sports', 'SUV', 'Sedan', 'Electric', 'Truck'];
  const fuelTypes = ['All', 'Gasoline', 'Electric', 'Hybrid'];
  const brands = ['All', 'Ferrari', 'Lamborghini', 'Porsche', 'BMW', 'Mercedes', 'Tesla', 'Hyundai', 'Jeep', 'Audi', 'Nissan', 'Chevrolet', 'Honda', 'Ford', 'Toyota', 'Land Rover', 'Cadillac', 'Dodge'];

  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <div className="flex items-center gap-2 mb-6">
        <SlidersHorizontal className="w-5 h-5 text-blue-600" />
        <h2 className="text-xl font-bold text-gray-900">Filters</h2>
      </div>

      <div className="space-y-6">
        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-3">Car Type</label>
          <div className="space-y-2">
            {carTypes.map((type) => (
              <button
                key={type}
                onClick={() => setSelectedType(type)}
                className={`w-full text-left px-4 py-2 rounded-lg transition-colors duration-200 ${
                  selectedType === type
                    ? 'bg-blue-600 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {type}
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-3">Fuel Type</label>
          <div className="space-y-2">
            {fuelTypes.map((fuel) => (
              <button
                key={fuel}
                onClick={() => setSelectedFuelType(fuel)}
                className={`w-full text-left px-4 py-2 rounded-lg transition-colors duration-200 ${
                  selectedFuelType === fuel
                    ? 'bg-blue-600 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {fuel}
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-3">Brand</label>
          <select
            value={selectedBrand}
            onChange={(e) => setSelectedBrand(e.target.value)}
            className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-600"
          >
            {brands.map((brand) => (
              <option key={brand} value={brand}>
                {brand}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-3">
            Price Range: ${priceRange[0].toLocaleString()} - ${priceRange[1].toLocaleString()}
          </label>
          <div className="space-y-3">
            <div>
              <label className="block text-xs text-gray-500 mb-1">Min Price</label>
              <input
                type="range"
                min="30000"
                max="500000"
                step="10000"
                value={priceRange[0]}
                onChange={(e) => setPriceRange([parseInt(e.target.value), priceRange[1]])}
                className="w-full"
              />
            </div>
            <div>
              <label className="block text-xs text-gray-500 mb-1">Max Price</label>
              <input
                type="range"
                min="30000"
                max="500000"
                step="10000"
                value={priceRange[1]}
                onChange={(e) => setPriceRange([priceRange[0], parseInt(e.target.value)])}
                className="w-full"
              />
            </div>
          </div>
        </div>

        <button
          onClick={() => {
            setSelectedType('All');
            setSelectedFuelType('All');
            setSelectedBrand('All');
            setPriceRange([30000, 500000]);
          }}
          className="w-full px-4 py-2 bg-gray-200 hover:bg-gray-300 text-gray-700 rounded-lg transition-colors duration-200"
        >
          Reset Filters
        </button>
      </div>
    </div>
  );
}
