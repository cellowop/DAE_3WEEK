import { useState } from 'react';
import { CarCard } from './components/CarCard';
import { FilterSidebar } from './components/FilterSidebar';
import { CarDetailsModal } from './components/CarDetailsModal';
import { Car, Search } from 'lucide-react';

interface CarData {
  id: number;
  name: string;
  brand: string;
  type: string;
  price: number;
  image: string;
  fuelType: string;
  horsepower: number;
  topSpeed: number;
  features: string[];
  engine: {
    type: string;
    displacement: string;
    configuration: string;
    cylinders: number;
    horsepower: number;
    torque: string;
  };
  transmission: {
    type: string;
    gears: number;
    driveType: string;
  };
  performance: {
    acceleration: string;
    topSpeed: number;
    fuelEconomy: string;
  };
  chassis: {
    suspension: string;
    brakes: string;
    wheels: string;
    tires: string;
  };
  interior: {
    seating: string;
    infotainment: string;
    safety: string[];
  };
  exterior: {
    length: string;
    width: string;
    height: string;
    weight: string;
  };
  warranty: {
    basic: string;
    powertrain: string;
    corrosion: string;
  };
  maintenance: {
    oilChange: string;
    tireRotation: string;
    brakeInspection: string;
  };
  colors: string[];
  technology: string[];
}

const carsData: CarData[] = [
  {
    id: 1,
    name: "488 GTB",
    brand: "Ferrari",
    type: "Sports",
    price: 280000,
    image: "https://images.unsplash.com/photo-1622945772259-d25c5a437f47?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080",
    fuelType: "Gasoline",
    horsepower: 660,
    topSpeed: 205,
    features: ["Twin-Turbo V8 Engine", "Carbon Fiber Body", "Advanced Aerodynamics", "7-Speed Dual-Clutch Transmission"],
    engine: {
      type: "Twin-Turbocharged V8",
      displacement: "3.9L",
      configuration: "Mid-Engine",
      cylinders: 8,
      horsepower: 660,
      torque: "561 lb-ft"
    },
    transmission: {
      type: "Dual-Clutch Automatic",
      gears: 7,
      driveType: "Rear-Wheel Drive"
    },
    performance: {
      acceleration: "3.0 seconds",
      topSpeed: 205,
      fuelEconomy: "15/22 MPG"
    },
    chassis: {
      suspension: "Adaptive Magnetorheological Dampers",
      brakes: "Carbon-Ceramic Disc Brakes",
      wheels: "20-inch Forged Aluminum",
      tires: "245/35 ZR20 (Front), 305/30 ZR20 (Rear)"
    },
    interior: {
      seating: "2-Seat Sports Configuration with Racing Seats",
      infotainment: "8.4-inch Touchscreen with Navigation",
      safety: ["Traction Control", "Electronic Stability Program", "ABS with EBD", "Dual Front Airbags", "Side-Slip Control"]
    },
    exterior: {
      length: "179.2 in",
      width: "76.9 in",
      height: "47.8 in",
      weight: "3,252 lbs"
    },
    warranty: {
      basic: "4 years / 50,000 miles",
      powertrain: "4 years / 50,000 miles",
      corrosion: "12 years unlimited miles"
    },
    maintenance: {
      oilChange: "Every 12,000 miles",
      tireRotation: "Every 7,500 miles",
      brakeInspection: "Every 12,000 miles"
    },
    colors: ["Rosso Corsa Red", "Nero Black", "Bianco Avus White", "Blu Pozzi Blue", "Grigio Titanio Gray"],
    technology: ["Launch Control", "Race Mode", "Side Slip Control 2.0", "F1-Trac Traction Control", "Electronic Differential", "Active Aerodynamics"]
  },
  {
    id: 2,
    name: "Aventador",
    brand: "Lamborghini",
    type: "Sports",
    price: 420000,
    image: "https://images.unsplash.com/photo-1742056024244-02a093dae0b5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080",
    fuelType: "Gasoline",
    horsepower: 730,
    topSpeed: 217,
    features: ["V12 Engine", "All-Wheel Drive", "Carbon Fiber Monocoque", "Adaptive Suspension"],
    engine: {
      type: "Naturally Aspirated V12",
      displacement: "6.5L",
      configuration: "Mid-Engine",
      cylinders: 12,
      horsepower: 730,
      torque: "509 lb-ft"
    },
    transmission: {
      type: "7-Speed Automated Manual",
      gears: 7,
      driveType: "All-Wheel Drive (AWD)"
    },
    performance: {
      acceleration: "2.9 seconds",
      topSpeed: 217,
      fuelEconomy: "11/18 MPG"
    },
    chassis: {
      suspension: "Pushrod Suspension with Adaptive Dampers",
      brakes: "Carbon-Ceramic Disc Brakes (400mm Front)",
      wheels: "20-inch Front / 21-inch Rear Forged",
      tires: "255/35 ZR19 (Front), 335/30 ZR20 (Rear)"
    },
    interior: {
      seating: "2-Seat Carbon Fiber Racing Seats",
      infotainment: "Lamborghini Infotainment System III",
      safety: ["Dynamic Steering", "ABS with EBD", "Traction Control", "Front and Side Airbags", "Electronic Stability Control"]
    },
    exterior: {
      length: "188.9 in",
      width: "79.9 in",
      height: "44.7 in",
      weight: "3,472 lbs"
    },
    warranty: {
      basic: "3 years / unlimited miles",
      powertrain: "3 years / unlimited miles",
      corrosion: "12 years unlimited miles"
    },
    maintenance: {
      oilChange: "Every 9,000 miles",
      tireRotation: "Every 6,000 miles",
      brakeInspection: "Every 9,000 miles"
    },
    colors: ["Arancio Argos Orange", "Nero Aldebaran Black", "Bianco Icarus White", "Blu Cepheus Blue", "Verde Mantis Green"],
    technology: ["Lamborghini Dinamica Veicolo Integrata (LDVI)", "Dynamic Steering", "4-Wheel Steering", "Cylinder Deactivation", "Thrust Mode", "Ego Mode Selector"]
  },
  {
    id: 3,
    name: "911 Turbo S",
    brand: "Porsche",
    type: "Sports",
    price: 207000,
    image: "https://images.unsplash.com/photo-1647340764627-11713b9d0f65?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080",
    fuelType: "Gasoline",
    horsepower: 640,
    topSpeed: 205,
    features: ["Twin-Turbo Flat-Six", "PDK Transmission", "Active Aerodynamics", "Sport Chrono Package"],
    engine: {
      type: "Twin-Turbocharged Flat-6",
      displacement: "3.8L",
      configuration: "Rear-Engine",
      cylinders: 6,
      horsepower: 640,
      torque: "590 lb-ft"
    },
    transmission: {
      type: "8-Speed PDK Dual-Clutch",
      gears: 8,
      driveType: "All-Wheel Drive (AWD)"
    },
    performance: {
      acceleration: "2.6 seconds",
      topSpeed: 205,
      fuelEconomy: "18/24 MPG"
    },
    chassis: {
      suspension: "Adaptive Air Suspension with PASM",
      brakes: "Porsche Ceramic Composite Brakes (PCCB)",
      wheels: "20-inch Front / 21-inch Rear",
      tires: "255/35 ZR20 (Front), 315/30 ZR21 (Rear)"
    },
    interior: {
      seating: "4-Seat Configuration with Sport Seats Plus",
      infotainment: "10.9-inch PCM with Navigation",
      safety: ["Adaptive Cruise Control", "Lane Keep Assist", "ParkAssist", "Porsche Stability Management", "Multiple Airbags"]
    },
    exterior: {
      length: "177.9 in",
      width: "74.8 in",
      height: "51.0 in",
      weight: "3,640 lbs"
    },
    warranty: {
      basic: "4 years / 50,000 miles",
      powertrain: "4 years / 50,000 miles",
      corrosion: "12 years unlimited miles"
    },
    maintenance: {
      oilChange: "Every 10,000 miles",
      tireRotation: "Every 10,000 miles",
      brakeInspection: "Every 10,000 miles"
    },
    colors: ["Carrera White", "Jet Black Metallic", "GT Silver Metallic", "Racing Yellow", "Miami Blue"],
    technology: ["Porsche Active Suspension Management (PASM)", "Sport Chrono Package", "Porsche Torque Vectoring Plus", "Wet Mode", "Night Vision Assist", "Adaptive Cruise Control"]
  },
  {
    id: 4,
    name: "AMG GT",
    brand: "Mercedes",
    type: "Sports",
    price: 118600,
    image: "https://images.unsplash.com/photo-1698543252450-463b8b16e567?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080",
    fuelType: "Gasoline",
    horsepower: 523,
    topSpeed: 193,
    features: ["Handcrafted AMG V8", "Rear-Wheel Drive", "Active Suspension", "AMG Performance Exhaust"],
    engine: {
      type: "Twin-Turbocharged V8",
      displacement: "4.0L",
      configuration: "Front Mid-Engine",
      cylinders: 8,
      horsepower: 523,
      torque: "494 lb-ft"
    },
    transmission: {
      type: "7-Speed AMG Speedshift DCT",
      gears: 7,
      driveType: "Rear-Wheel Drive"
    },
    performance: {
      acceleration: "3.9 seconds",
      topSpeed: 193,
      fuelEconomy: "16/22 MPG"
    },
    chassis: {
      suspension: "AMG Ride Control Adaptive Suspension",
      brakes: "AMG High-Performance Braking System",
      wheels: "19-inch AMG Alloy Wheels",
      tires: "265/35 ZR19 (Front), 295/30 ZR19 (Rear)"
    },
    interior: {
      seating: "2-Seat AMG Performance Seats",
      infotainment: "12.3-inch MBUX Infotainment",
      safety: ["Active Brake Assist", "Attention Assist", "ESP Dynamic Stability", "Crosswind Assist", "Multiple Airbags"]
    },
    exterior: {
      length: "178.7 in",
      width: "76.3 in",
      height: "50.6 in",
      weight: "3,594 lbs"
    },
    warranty: {
      basic: "4 years / 50,000 miles",
      powertrain: "4 years / 50,000 miles",
      corrosion: "5 years unlimited miles"
    },
    maintenance: {
      oilChange: "Every 10,000 miles",
      tireRotation: "Every 10,000 miles",
      brakeInspection: "Every 10,000 miles"
    },
    colors: ["Designo Cardinal Red", "Obsidian Black", "Selenite Grey", "Sun Yellow", "AMG Green Hell Magno"],
    technology: ["AMG Track Pace", "AMG Dynamic Select", "Drift Mode", "Race Start Function", "Active Exhaust System", "Burmester Surround Sound"]
  },
  {
    id: 5,
    name: "Tucson",
    brand: "Hyundai",
    type: "SUV",
    price: 32000,
    image: "https://images.unsplash.com/photo-1650959818516-03d68079f9a0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080",
    fuelType: "Hybrid",
    horsepower: 226,
    topSpeed: 130,
    features: ["Hybrid Powertrain", "All-Wheel Drive", "Smart Cruise Control", "Panoramic Sunroof"],
    engine: {
      type: "Hybrid Inline-4 with Electric Motor",
      displacement: "1.6L Turbo + Electric",
      configuration: "Front-Engine",
      cylinders: 4,
      horsepower: 226,
      torque: "258 lb-ft"
    },
    transmission: {
      type: "6-Speed Automatic",
      gears: 6,
      driveType: "All-Wheel Drive (HTRAC)"
    },
    performance: {
      acceleration: "7.5 seconds",
      topSpeed: 130,
      fuelEconomy: "38/38 MPG"
    },
    chassis: {
      suspension: "MacPherson Strut Front / Multi-Link Rear",
      brakes: "Disc Brakes with Regenerative Braking",
      wheels: "18-inch Alloy Wheels",
      tires: "235/60 R18"
    },
    interior: {
      seating: "5-Passenger with Heated Front Seats",
      infotainment: "10.25-inch Touchscreen with Apple CarPlay",
      safety: ["Forward Collision Avoidance", "Blind-Spot Monitoring", "Lane Keep Assist", "Smart Cruise Control", "Multiple Airbags"]
    },
    exterior: {
      length: "182.3 in",
      width: "72.8 in",
      height: "65.6 in",
      weight: "3,737 lbs"
    },
    warranty: {
      basic: "5 years / 60,000 miles",
      powertrain: "10 years / 100,000 miles",
      corrosion: "7 years / unlimited miles"
    },
    maintenance: {
      oilChange: "Every 7,500 miles",
      tireRotation: "Every 7,500 miles",
      brakeInspection: "Every 15,000 miles"
    },
    colors: ["Amazon Gray", "Shimmering Silver", "Phantom Black", "Crimson Red", "Atlas White"],
    technology: ["Smart Cruise Control with Stop & Go", "Highway Driving Assist", "Blind-Spot Collision Avoidance", "Parking Collision-Avoidance Assist", "Digital Key", "Wireless Charging"]
  },
  {
    id: 6,
    name: "X5 M",
    brand: "BMW",
    type: "SUV",
    price: 106000,
    image: "https://images.unsplash.com/photo-1618353482480-61ca5a9a7a79?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080",
    fuelType: "Gasoline",
    horsepower: 617,
    topSpeed: 177,
    features: ["Twin-Turbo V8", "M xDrive AWD", "Adaptive M Suspension", "Carbon Fiber Trim"],
    engine: {
      type: "Twin-Turbocharged V8",
      displacement: "4.4L",
      configuration: "Front-Engine",
      cylinders: 8,
      horsepower: 617,
      torque: "553 lb-ft"
    },
    transmission: {
      type: "8-Speed M Steptronic",
      gears: 8,
      driveType: "M xDrive All-Wheel Drive"
    },
    performance: {
      acceleration: "3.8 seconds",
      topSpeed: 177,
      fuelEconomy: "13/18 MPG"
    },
    chassis: {
      suspension: "Adaptive M Suspension Professional",
      brakes: "M Compound Brakes with Blue Calipers",
      wheels: "21-inch M Light Alloy Wheels",
      tires: "285/40 R21 (Front), 315/35 R21 (Rear)"
    },
    interior: {
      seating: "5-Passenger with M Sport Seats",
      infotainment: "12.3-inch iDrive 7.0 System",
      safety: ["Active Protection", "Lane Departure Warning", "Parking Assistant", "Surround View", "Multiple Airbags"]
    },
    exterior: {
      length: "194.3 in",
      width: "78.9 in",
      height: "69.7 in",
      weight: "5,290 lbs"
    },
    warranty: {
      basic: "4 years / 50,000 miles",
      powertrain: "4 years / 50,000 miles",
      corrosion: "12 years unlimited miles"
    },
    maintenance: {
      oilChange: "Every 10,000 miles",
      tireRotation: "Every 10,000 miles",
      brakeInspection: "Every 10,000 miles"
    },
    colors: ["Marina Bay Blue", "Black Sapphire", "Alpine White", "Brooklyn Grey", "Ametrin Metallic"],
    technology: ["M xDrive with Torque Vectoring", "Launch Control", "M Mode Button", "Head-Up Display", "Gesture Control", "Harman Kardon Sound System"]
  },
  {
    id: 7,
    name: "Wrangler",
    brand: "Jeep",
    type: "SUV",
    price: 35000,
    image: "https://images.unsplash.com/photo-1506015391300-4802dc74de2e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080",
    fuelType: "Gasoline",
    horsepower: 285,
    topSpeed: 110,
    features: ["4x4 Off-Road System", "Removable Doors & Top", "Skid Plates", "Trail-Rated Badge"],
    engine: {
      type: "V6 Pentastar",
      displacement: "3.6L",
      configuration: "Front-Engine",
      cylinders: 6,
      horsepower: 285,
      torque: "260 lb-ft"
    },
    transmission: {
      type: "8-Speed Automatic",
      gears: 8,
      driveType: "4WD Part-Time"
    },
    performance: {
      acceleration: "7.8 seconds",
      topSpeed: 110,
      fuelEconomy: "18/23 MPG"
    },
    chassis: {
      suspension: "5-Link Coil Suspension Front & Rear",
      brakes: "Vented Disc Brakes",
      wheels: "17-inch Steel Wheels",
      tires: "245/75 R17 All-Terrain"
    },
    interior: {
      seating: "5-Passenger with Water-Resistant Seats",
      infotainment: "8.4-inch Uconnect Touchscreen",
      safety: ["Blind Spot Monitoring", "Rear Cross Traffic Alert", "Electronic Stability Control", "Hill Start Assist", "Multiple Airbags"]
    },
    exterior: {
      length: "188.4 in",
      width: "73.8 in",
      height: "73.6 in",
      weight: "4,449 lbs"
    },
    warranty: {
      basic: "3 years / 36,000 miles",
      powertrain: "5 years / 60,000 miles",
      corrosion: "5 years unlimited miles"
    },
    maintenance: {
      oilChange: "Every 8,000 miles",
      tireRotation: "Every 8,000 miles",
      brakeInspection: "Every 16,000 miles"
    },
    colors: ["Firecracker Red", "Black", "Bright White", "Granite Crystal", "Sarge Green"],
    technology: ["Rock-Trac 4x4 System", "Electronic Sway Bar Disconnect", "Hill Descent Control", "Selec-Speed Control", "Forward Facing TrailCam", "Uconnect 4C NAV"]
  },
  {
    id: 8,
    name: "Model S Plaid",
    brand: "Tesla",
    type: "Electric",
    price: 109990,
    image: "https://images.unsplash.com/photo-1615829386703-e2bb66a7cb7d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080",
    fuelType: "Electric",
    horsepower: 1020,
    topSpeed: 200,
    features: ["Tri-Motor AWD", "1,020 HP", "390 Mile Range", "Autopilot", "Ludicrous Mode"],
    engine: {
      type: "Tri-Motor Electric",
      displacement: "N/A (Electric)",
      configuration: "Front & Dual Rear Motors",
      cylinders: 0,
      horsepower: 1020,
      torque: "1,050 lb-ft"
    },
    transmission: {
      type: "Single-Speed Direct Drive",
      gears: 1,
      driveType: "All-Wheel Drive (Tri-Motor)"
    },
    performance: {
      acceleration: "1.99 seconds",
      topSpeed: 200,
      fuelEconomy: "120 MPGe (Combined)"
    },
    chassis: {
      suspension: "Adaptive Air Suspension",
      brakes: "Regenerative + Hydraulic Disc Brakes",
      wheels: "19-inch Tempest Wheels",
      tires: "255/45 R19 (Front), 285/40 R19 (Rear)"
    },
    interior: {
      seating: "5-Passenger with Vegan Leather",
      infotainment: "17-inch Horizontal Touchscreen",
      safety: ["Autopilot", "Full Self-Driving Capability", "Automatic Emergency Braking", "Collision Warning", "8 Airbags"]
    },
    exterior: {
      length: "196.0 in",
      width: "77.3 in",
      height: "56.9 in",
      weight: "4,766 lbs"
    },
    warranty: {
      basic: "4 years / 50,000 miles",
      powertrain: "8 years / 150,000 miles (Battery)",
      corrosion: "12 years unlimited miles"
    },
    maintenance: {
      oilChange: "N/A (Electric)",
      tireRotation: "Every 6,250 miles",
      brakeInspection: "Every 12,500 miles"
    },
    colors: ["Pearl White Multi-Coat", "Solid Black", "Midnight Silver Metallic", "Deep Blue Metallic", "Red Multi-Coat"],
    technology: ["Autopilot", "Full Self-Driving Capability", "Summon", "Navigate on Autopilot", "Auto Lane Change", "Autopark", "Smart Summon", "Traffic Light Recognition"]
  },
  {
    id: 9,
    name: "iX",
    brand: "BMW",
    type: "Electric",
    price: 87250,
    image: "https://images.unsplash.com/photo-1615063029891-497bebd4f03c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080",
    fuelType: "Electric",
    horsepower: 516,
    topSpeed: 124,
    features: ["Dual Motor AWD", "324 Mile Range", "Auto-Driving Tech", "Curved Display"],
    engine: {
      type: "Dual Electric Motors",
      displacement: "N/A (Electric)",
      configuration: "Front & Rear Motors",
      cylinders: 0,
      horsepower: 516,
      torque: "564 lb-ft"
    },
    transmission: {
      type: "Single-Speed Automatic",
      gears: 1,
      driveType: "All-Wheel Drive (xDrive)"
    },
    performance: {
      acceleration: "4.6 seconds",
      topSpeed: 124,
      fuelEconomy: "86 MPGe (Combined)"
    },
    chassis: {
      suspension: "Adaptive Air Suspension",
      brakes: "Regenerative + Disc Brakes",
      wheels: "21-inch Aerodynamic Wheels",
      tires: "255/55 R21 (Front), 275/50 R21 (Rear)"
    },
    interior: {
      seating: "5-Passenger with Sustainable Materials",
      infotainment: "Curved Display with iDrive 8",
      safety: ["Driving Assistant Professional", "Active Lane Keep", "Parking Assistant", "Surround View Camera", "Multiple Airbags"]
    },
    exterior: {
      length: "195.8 in",
      width: "77.4 in",
      height: "66.8 in",
      weight: "5,659 lbs"
    },
    warranty: {
      basic: "4 years / 50,000 miles",
      powertrain: "8 years / 100,000 miles (Battery)",
      corrosion: "12 years unlimited miles"
    },
    maintenance: {
      oilChange: "N/A (Electric)",
      tireRotation: "Every 10,000 miles",
      brakeInspection: "Every 10,000 miles"
    },
    colors: ["Storm Bay Metallic", "Mineral White", "Aventurine Red", "Space Grey", "Oxide Grey"],
    technology: ["BMW Curved Display", "iDrive 8", "Driving Assistant Professional", "Parking Assistant Plus", "Reversing Assistant", "BMW Digital Key Plus", "Bowers & Wilkins Sound"]
  },
  {
    id: 10,
    name: "5 Series",
    brand: "BMW",
    type: "Sedan",
    price: 55000,
    image: "https://images.unsplash.com/photo-1661311928926-180711852306?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080",
    fuelType: "Gasoline",
    horsepower: 335,
    topSpeed: 155,
    features: ["Turbocharged Inline-6", "Luxury Interior", "iDrive Infotainment", "Adaptive LED Headlights"],
    engine: {
      type: "Turbocharged Inline-6",
      displacement: "3.0L",
      configuration: "Front-Engine",
      cylinders: 6,
      horsepower: 335,
      torque: "331 lb-ft"
    },
    transmission: {
      type: "8-Speed Automatic",
      gears: 8,
      driveType: "Rear-Wheel Drive"
    },
    performance: {
      acceleration: "5.3 seconds",
      topSpeed: 155,
      fuelEconomy: "25/34 MPG"
    },
    chassis: {
      suspension: "Adaptive M Suspension",
      brakes: "Ventilated Disc Brakes",
      wheels: "18-inch Alloy Wheels",
      tires: "245/45 R18 (Front), 275/40 R18 (Rear)"
    },
    interior: {
      seating: "5-Passenger with Vernasca Leather",
      infotainment: "12.3-inch iDrive Touchscreen",
      safety: ["Active Driving Assistant", "Lane Departure Warning", "Blind Spot Detection", "Parking Assistant", "Multiple Airbags"]
    },
    exterior: {
      length: "194.6 in",
      width: "73.0 in",
      height: "58.3 in",
      weight: "3,990 lbs"
    },
    warranty: {
      basic: "4 years / 50,000 miles",
      powertrain: "4 years / 50,000 miles",
      corrosion: "12 years unlimited miles"
    },
    maintenance: {
      oilChange: "Every 10,000 miles",
      tireRotation: "Every 10,000 miles",
      brakeInspection: "Every 10,000 miles"
    },
    colors: ["Black Sapphire Metallic", "Alpine White", "Phytonic Blue", "Bernina Grey Amber", "M Brooklyn Grey"],
    technology: ["BMW Live Cockpit Professional", "Adaptive M Suspension", "Parking Assistant", "Wireless Charging", "Gesture Control", "Head-Up Display"]
  },
  {
    id: 11,
    name: "S-Class",
    brand: "Mercedes",
    type: "Sedan",
    price: 115000,
    image: "https://images.unsplash.com/photo-1764605206511-7a649d9df63b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080",
    fuelType: "Gasoline",
    horsepower: 429,
    topSpeed: 155,
    features: ["Turbocharged Inline-6 with EQ Boost", "4MATIC All-Wheel Drive", "AIRMATIC Suspension", "MBUX Hyperscreen"],
    engine: {
      type: "Turbocharged Inline-6 with EQ Boost",
      displacement: "3.0L",
      configuration: "Front-Engine",
      cylinders: 6,
      horsepower: 429,
      torque: "384 lb-ft"
    },
    transmission: {
      type: "9-Speed Automatic",
      gears: 9,
      driveType: "4MATIC All-Wheel Drive"
    },
    performance: {
      acceleration: "4.9 seconds",
      topSpeed: 155,
      fuelEconomy: "21/28 MPG"
    },
    chassis: {
      suspension: "AIRMATIC Adaptive Air Suspension",
      brakes: "Vented Disc Brakes with Brake Assist",
      wheels: "20-inch AMG Multi-Spoke Wheels",
      tires: "255/40 R20 (Front), 285/35 R20 (Rear)"
    },
    interior: {
      seating: "5-Passenger with Nappa Leather",
      infotainment: "MBUX Hyperscreen with Triple Display",
      safety: ["PRE-SAFE", "Active Brake Assist", "Active Steering Assist", "Blind Spot Assist", "9 Airbags"]
    },
    exterior: {
      length: "206.5 in",
      width: "75.8 in",
      height: "59.4 in",
      weight: "4,740 lbs"
    },
    warranty: {
      basic: "4 years / 50,000 miles",
      powertrain: "4 years / 50,000 miles",
      corrosion: "4 years / 50,000 miles"
    },
    maintenance: {
      oilChange: "Every 10,000 miles",
      tireRotation: "Every 10,000 miles",
      brakeInspection: "Every 10,000 miles"
    },
    colors: ["Obsidian Black", "Polar White", "Selenite Grey", "Designo Diamond White", "Mojave Silver"],
    technology: ["MBUX Augmented Reality Navigation", "E-Active Body Control", "Energizing Comfort Control", "Burmester 4D Sound", "Digital Light Headlamps", "Rear Axle Steering"]
  },
  {
    id: 12,
    name: "A8",
    brand: "Audi",
    type: "Sedan",
    price: 87000,
    image: "https://images.unsplash.com/photo-1706977384830-df8b515e6b70?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080",
    fuelType: "Gasoline",
    horsepower: 335,
    topSpeed: 130,
    features: ["Turbocharged V6", "Quattro AWD", "Adaptive Air Suspension", "Virtual Cockpit Plus"],
    engine: {
      type: "Turbocharged V6",
      displacement: "3.0L",
      configuration: "Front-Engine",
      cylinders: 6,
      horsepower: 335,
      torque: "369 lb-ft"
    },
    transmission: {
      type: "8-Speed Tiptronic",
      gears: 8,
      driveType: "Quattro All-Wheel Drive"
    },
    performance: {
      acceleration: "5.6 seconds",
      topSpeed: 130,
      fuelEconomy: "19/27 MPG"
    },
    chassis: {
      suspension: "Adaptive Air Suspension Sport",
      brakes: "Vented Disc Brakes",
      wheels: "19-inch Aluminum Wheels",
      tires: "255/45 R19"
    },
    interior: {
      seating: "5-Passenger with Valcona Leather",
      infotainment: "MMI Touch Response with Dual Screens",
      safety: ["Audi Pre Sense", "Adaptive Cruise Assist", "Lane Departure Warning", "360-Degree Camera", "8 Airbags"]
    },
    exterior: {
      length: "208.7 in",
      width: "76.7 in",
      height: "58.2 in",
      weight: "4,598 lbs"
    },
    warranty: {
      basic: "4 years / 50,000 miles",
      powertrain: "4 years / 50,000 miles",
      corrosion: "12 years unlimited miles"
    },
    maintenance: {
      oilChange: "Every 10,000 miles",
      tireRotation: "Every 10,000 miles",
      brakeInspection: "Every 10,000 miles"
    },
    colors: ["Mythos Black", "Glacier White", "Daytona Grey", "Navarra Blue", "Florett Silver"],
    technology: ["Audi Virtual Cockpit Plus", "Predictive Active Suspension", "Traffic Jam Pilot", "Bang & Olufsen 3D Sound", "Matrix LED Headlights", "Mild Hybrid Technology"]
  },
  {
    id: 13,
    name: "GT-R",
    brand: "Nissan",
    type: "Sports",
    price: 115000,
    image: "https://images.unsplash.com/photo-1653047256226-5abbfa82f1d7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080",
    fuelType: "Gasoline",
    horsepower: 565,
    topSpeed: 196,
    features: ["Twin-Turbo V6", "All-Wheel Drive", "Bilstein DampTronic Suspension", "Launch Control"],
    engine: {
      type: "Twin-Turbocharged V6",
      displacement: "3.8L",
      configuration: "Front Mid-Engine",
      cylinders: 6,
      horsepower: 565,
      torque: "467 lb-ft"
    },
    transmission: {
      type: "6-Speed Dual-Clutch",
      gears: 6,
      driveType: "ATTESA E-TS All-Wheel Drive"
    },
    performance: {
      acceleration: "2.9 seconds",
      topSpeed: 196,
      fuelEconomy: "16/22 MPG"
    },
    chassis: {
      suspension: "Bilstein DampTronic Adaptive Dampers",
      brakes: "Brembo 6-Piston Front Calipers",
      wheels: "20-inch RAYS Forged Aluminum",
      tires: "255/40 ZR20 (Front), 285/35 ZR20 (Rear)"
    },
    interior: {
      seating: "4-Seat with Recaro Sport Seats",
      infotainment: "8-inch NissanConnect Touchscreen",
      safety: ["Vehicle Dynamic Control", "Traction Control", "ABS with EBD", "Front and Side Airbags", "Tire Pressure Monitoring"]
    },
    exterior: {
      length: "185.4 in",
      width: "74.6 in",
      height: "53.9 in",
      weight: "3,933 lbs"
    },
    warranty: {
      basic: "3 years / 36,000 miles",
      powertrain: "5 years / 60,000 miles",
      corrosion: "5 years unlimited miles"
    },
    maintenance: {
      oilChange: "Every 6,000 miles",
      tireRotation: "Every 7,500 miles",
      brakeInspection: "Every 7,500 miles"
    },
    colors: ["Bayside Blue", "Jet Black", "Pearl White", "Gun Metallic", "Ultimate Red"],
    technology: ["Launch Control", "R-Mode Driving Modes", "Nismo-Tuned Suspension", "Carbon Fiber Driveshaft", "Titanium Exhaust", "Multi-Function Display"]
  },
  {
    id: 14,
    name: "Corvette C8",
    brand: "Chevrolet",
    type: "Sports",
    price: 68000,
    image: "https://images.unsplash.com/photo-1653047260382-395a1fca3501?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080",
    fuelType: "Gasoline",
    horsepower: 495,
    topSpeed: 194,
    features: ["Mid-Engine V8", "Magnetic Ride Control", "Electronic Limited-Slip Differential", "Performance Exhaust"],
    engine: {
      type: "Naturally Aspirated V8",
      displacement: "6.2L LT2",
      configuration: "Mid-Engine",
      cylinders: 8,
      horsepower: 495,
      torque: "470 lb-ft"
    },
    transmission: {
      type: "8-Speed Dual-Clutch",
      gears: 8,
      driveType: "Rear-Wheel Drive"
    },
    performance: {
      acceleration: "2.9 seconds",
      topSpeed: 194,
      fuelEconomy: "15/27 MPG"
    },
    chassis: {
      suspension: "Magnetic Ride Control 4.0",
      brakes: "Brembo Performance Brakes",
      wheels: "19-inch Front / 20-inch Rear Aluminum",
      tires: "245/35 ZR19 (Front), 305/30 ZR20 (Rear)"
    },
    interior: {
      seating: "2-Seat with GT Sport Seats",
      infotainment: "12-inch Customizable Driver Display",
      safety: ["Front and Side Airbags", "Rear Camera Mirror", "Front and Rear Park Assist", "Tire Pressure Monitoring", "OnStar"]
    },
    exterior: {
      length: "182.3 in",
      width: "76.1 in",
      height: "48.6 in",
      weight: "3,647 lbs"
    },
    warranty: {
      basic: "3 years / 36,000 miles",
      powertrain: "5 years / 60,000 miles",
      corrosion: "6 years / 100,000 miles"
    },
    maintenance: {
      oilChange: "Every 7,500 miles",
      tireRotation: "Every 7,500 miles",
      brakeInspection: "Every 7,500 miles"
    },
    colors: ["Arctic White", "Torch Red", "Rapid Blue", "Zeus Bronze", "Black"],
    technology: ["Performance Data Recorder", "Head-Up Display", "Driver Mode Selector", "Electronic Limited-Slip Differential", "Launch Control", "Performance Traction Management"]
  },
  {
    id: 15,
    name: "Civic Type R",
    brand: "Honda",
    type: "Sports",
    price: 43000,
    image: "https://images.unsplash.com/photo-1653047256366-9bd8927f98a0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080",
    fuelType: "Gasoline",
    horsepower: 315,
    topSpeed: 170,
    features: ["Turbocharged 4-Cylinder", "6-Speed Manual", "Adaptive Damper System", "Limited-Slip Differential"],
    engine: {
      type: "Turbocharged Inline-4 VTEC",
      displacement: "2.0L",
      configuration: "Front-Engine",
      cylinders: 4,
      horsepower: 315,
      torque: "310 lb-ft"
    },
    transmission: {
      type: "6-Speed Manual",
      gears: 6,
      driveType: "Front-Wheel Drive"
    },
    performance: {
      acceleration: "5.0 seconds",
      topSpeed: 170,
      fuelEconomy: "22/28 MPG"
    },
    chassis: {
      suspension: "Adaptive Damper System",
      brakes: "Brembo 4-Piston Front Calipers",
      wheels: "19-inch Gloss Black Alloy",
      tires: "265/30 R19 Michelin Pilot Sport 4S"
    },
    interior: {
      seating: "5-Passenger with Sport Bucket Seats",
      infotainment: "9-inch Honda Infotainment Touchscreen",
      safety: ["Honda Sensing Suite", "Adaptive Cruise Control", "Lane Keep Assist", "Collision Mitigation Braking", "6 Airbags"]
    },
    exterior: {
      length: "179.8 in",
      width: "73.9 in",
      height: "56.5 in",
      weight: "3,186 lbs"
    },
    warranty: {
      basic: "3 years / 36,000 miles",
      powertrain: "5 years / 60,000 miles",
      corrosion: "5 years / unlimited miles"
    },
    maintenance: {
      oilChange: "Every 7,500 miles",
      tireRotation: "Every 7,500 miles",
      brakeInspection: "Every 15,000 miles"
    },
    colors: ["Championship White", "Sonic Gray Pearl", "Rallye Red", "Crystal Black Pearl", "Boost Blue Pearl"],
    technology: ["+R Driving Mode", "Individual Mode", "Comfort Mode", "Rev Match System", "Honda LogR Performance Data Logger", "Dual-Zone Climate Control"]
  },
  {
    id: 16,
    name: "F-150 Raptor",
    brand: "Ford",
    type: "Truck",
    price: 77000,
    image: "https://images.unsplash.com/photo-1551830820-330a71b99659?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080",
    fuelType: "Gasoline",
    horsepower: 450,
    topSpeed: 110,
    features: ["Twin-Turbo V6", "4WD with Terrain Modes", "Fox Live Valve Shocks", "Beadlock-Capable Wheels"],
    engine: {
      type: "Twin-Turbocharged V6 EcoBoost",
      displacement: "3.5L",
      configuration: "Front-Engine",
      cylinders: 6,
      horsepower: 450,
      torque: "510 lb-ft"
    },
    transmission: {
      type: "10-Speed Automatic",
      gears: 10,
      driveType: "4WD Part-Time"
    },
    performance: {
      acceleration: "5.1 seconds",
      topSpeed: 110,
      fuelEconomy: "15/18 MPG"
    },
    chassis: {
      suspension: "Fox 3.1 Live Valve Internal Bypass Shocks",
      brakes: "Power 4-Wheel Disc Brakes with ABS",
      wheels: "17-inch Beadlock-Capable",
      tires: "35-inch BFGoodrich All-Terrain T/A KO2"
    },
    interior: {
      seating: "5-Passenger SuperCrew with Recaro Seats",
      infotainment: "12-inch SYNC 4 Touchscreen",
      safety: ["Ford Co-Pilot360", "Blind Spot Monitoring", "Rear Cross Traffic Alert", "Pre-Collision Assist", "7 Airbags"]
    },
    exterior: {
      length: "231.9 in",
      width: "86.6 in",
      height: "79.8 in",
      weight: "5,740 lbs"
    },
    warranty: {
      basic: "3 years / 36,000 miles",
      powertrain: "5 years / 60,000 miles",
      corrosion: "5 years / unlimited miles"
    },
    maintenance: {
      oilChange: "Every 10,000 miles",
      tireRotation: "Every 7,500 miles",
      brakeInspection: "Every 10,000 miles"
    },
    colors: ["Avalanche Gray", "Code Orange", "Velocity Blue", "Oxford White", "Antimatter Blue"],
    technology: ["Terrain Management System", "Trail Control", "Trail Turn Assist", "One-Pedal Driving", "360-Degree Camera", "B&O Sound System"]
  },
  {
    id: 17,
    name: "Silverado 1500 ZR2",
    brand: "Chevrolet",
    type: "Truck",
    price: 73000,
    image: "https://images.unsplash.com/photo-1649793395985-967862a3b73f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080",
    fuelType: "Gasoline",
    horsepower: 420,
    topSpeed: 105,
    features: ["V8 Engine", "Multimatic DSSV Dampers", "Electronic Locking Differentials", "Off-Road Skid Plates"],
    engine: {
      type: "Naturally Aspirated V8",
      displacement: "6.2L",
      configuration: "Front-Engine",
      cylinders: 8,
      horsepower: 420,
      torque: "460 lb-ft"
    },
    transmission: {
      type: "10-Speed Automatic",
      gears: 10,
      driveType: "4WD with Auto Mode"
    },
    performance: {
      acceleration: "6.0 seconds",
      topSpeed: 105,
      fuelEconomy: "14/18 MPG"
    },
    chassis: {
      suspension: "Multimatic DSSV Dampers with Position-Sensitive Tech",
      brakes: "4-Wheel Disc Brakes with Duralife Rotors",
      wheels: "18-inch Machined Aluminum",
      tires: "33-inch Goodyear Wrangler Territory MT"
    },
    interior: {
      seating: "5-Passenger Crew Cab with Leather Seats",
      infotainment: "13.4-inch Infotainment Touchscreen",
      safety: ["Automatic Emergency Braking", "Lane Keep Assist", "Blind Zone Steering Assist", "Rear Camera", "6 Airbags"]
    },
    exterior: {
      length: "231.9 in",
      width: "81.2 in",
      height: "79.8 in",
      weight: "5,600 lbs"
    },
    warranty: {
      basic: "3 years / 36,000 miles",
      powertrain: "5 years / 60,000 miles",
      corrosion: "6 years / 100,000 miles"
    },
    maintenance: {
      oilChange: "Every 7,500 miles",
      tireRotation: "Every 7,500 miles",
      brakeInspection: "Every 7,500 miles"
    },
    colors: ["Red Hot", "Black", "Summit White", "Glacier Blue", "Sterling Gray"],
    technology: ["Terrain Mode Selection", "Hill Descent Control", "MyChevrolet Mobile App", "Super Cruise (Available)", "Bose Premium Audio", "Wireless Charging"]
  },
  {
    id: 18,
    name: "Tundra TRD Pro",
    brand: "Toyota",
    type: "Truck",
    price: 72000,
    image: "https://images.unsplash.com/photo-1559416523-140ddc3d238c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080",
    fuelType: "Hybrid",
    horsepower: 437,
    topSpeed: 110,
    features: ["Hybrid Twin-Turbo V6", "TRD Fox Shocks", "Multi-Terrain Select", "Crawl Control"],
    engine: {
      type: "Twin-Turbo V6 i-FORCE MAX Hybrid",
      displacement: "3.5L + Electric Motor",
      configuration: "Front-Engine",
      cylinders: 6,
      horsepower: 437,
      torque: "583 lb-ft"
    },
    transmission: {
      type: "10-Speed Automatic",
      gears: 10,
      driveType: "4WD with Part-Time"
    },
    performance: {
      acceleration: "6.1 seconds",
      topSpeed: 110,
      fuelEconomy: "19/22 MPG"
    },
    chassis: {
      suspension: "TRD-Tuned Fox Internal Bypass Shocks",
      brakes: "4-Wheel Disc Brakes with Brake Override",
      wheels: "18-inch TRD Black Alloy",
      tires: "33-inch Falken Wildpeak A/T"
    },
    interior: {
      seating: "5-Passenger CrewMax with TRD Sport Seats",
      infotainment: "14-inch Touchscreen with JBL Audio",
      safety: ["Toyota Safety Sense 2.5", "Pre-Collision System", "Lane Departure Alert", "Adaptive Cruise Control", "10 Airbags"]
    },
    exterior: {
      length: "233.6 in",
      width: "80.2 in",
      height: "78.0 in",
      weight: "5,795 lbs"
    },
    warranty: {
      basic: "3 years / 36,000 miles",
      powertrain: "5 years / 60,000 miles",
      corrosion: "5 years / unlimited miles"
    },
    maintenance: {
      oilChange: "Every 10,000 miles",
      tireRotation: "Every 5,000 miles",
      brakeInspection: "Every 10,000 miles"
    },
    colors: ["Solar Octane", "Midnight Black Metallic", "Ice Cap", "Army Green", "Supersonic Red"],
    technology: ["Multi-Terrain Select", "Crawl Control", "Downhill Assist Control", "Panoramic View Monitor", "TRD Pro Mode", "Smart Key System"]
  },
  {
    id: 19,
    name: "Range Rover",
    brand: "Land Rover",
    type: "SUV",
    price: 108000,
    image: "https://images.unsplash.com/photo-1700884520248-92092bd21e63?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080",
    fuelType: "Gasoline",
    horsepower: 395,
    topSpeed: 140,
    features: ["Mild Hybrid Inline-6", "All-Wheel Drive", "Air Suspension", "Terrain Response 2"],
    engine: {
      type: "Turbocharged Inline-6 with Mild Hybrid",
      displacement: "3.0L",
      configuration: "Front-Engine",
      cylinders: 6,
      horsepower: 395,
      torque: "406 lb-ft"
    },
    transmission: {
      type: "8-Speed Automatic",
      gears: 8,
      driveType: "All-Wheel Drive"
    },
    performance: {
      acceleration: "5.8 seconds",
      topSpeed: 140,
      fuelEconomy: "19/24 MPG"
    },
    chassis: {
      suspension: "Electronic Air Suspension with Adaptive Dynamics",
      brakes: "4-Wheel Ventilated Disc Brakes",
      wheels: "22-inch 10-Spoke Alloy",
      tires: "285/45 R22"
    },
    interior: {
      seating: "5-Passenger with Windsor Leather",
      infotainment: "Pivi Pro with Curved Displays",
      safety: ["3D Surround Camera", "Adaptive Cruise Control", "Lane Keep Assist", "Emergency Braking", "Multiple Airbags"]
    },
    exterior: {
      length: "196.9 in",
      width: "78.2 in",
      height: "72.0 in",
      weight: "5,390 lbs"
    },
    warranty: {
      basic: "4 years / 50,000 miles",
      powertrain: "4 years / 50,000 miles",
      corrosion: "6 years / unlimited miles"
    },
    maintenance: {
      oilChange: "Every 16,000 miles",
      tireRotation: "Every 8,000 miles",
      brakeInspection: "Every 16,000 miles"
    },
    colors: ["Fuji White", "Santorini Black", "Eiger Grey", "Portofino Blue", "Firenze Red"],
    technology: ["Terrain Response 2", "All-Wheel Steering", "ClearSight Ground View", "Cabin Air Purification Plus", "Meridian Signature Sound", "Head-Up Display"]
  },
  {
    id: 20,
    name: "Escalade",
    brand: "Cadillac",
    type: "SUV",
    price: 85000,
    image: "https://images.unsplash.com/photo-1767749995450-7b63ab7cd4fd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080",
    fuelType: "Gasoline",
    horsepower: 420,
    topSpeed: 130,
    features: ["V8 Engine", "Magnetic Ride Control", "Independent Rear Suspension", "38-inch OLED Display"],
    engine: {
      type: "Naturally Aspirated V8",
      displacement: "6.2L",
      configuration: "Front-Engine",
      cylinders: 8,
      horsepower: 420,
      torque: "460 lb-ft"
    },
    transmission: {
      type: "10-Speed Automatic",
      gears: 10,
      driveType: "Rear-Wheel Drive"
    },
    performance: {
      acceleration: "6.1 seconds",
      topSpeed: 130,
      fuelEconomy: "15/21 MPG"
    },
    chassis: {
      suspension: "Magnetic Ride Control 4.0",
      brakes: "Brembo Front Brakes",
      wheels: "22-inch Premium Alloy",
      tires: "275/50 R22"
    },
    interior: {
      seating: "7-Passenger with Semi-Aniline Leather",
      infotainment: "38-inch Curved OLED Display",
      safety: ["Super Cruise", "Enhanced Automatic Emergency Braking", "HD Surround Vision", "Rear Camera Mirror", "11 Airbags"]
    },
    exterior: {
      length: "211.9 in",
      width: "81.1 in",
      height: "76.7 in",
      weight: "5,881 lbs"
    },
    warranty: {
      basic: "4 years / 50,000 miles",
      powertrain: "6 years / 70,000 miles",
      corrosion: "6 years / 100,000 miles"
    },
    maintenance: {
      oilChange: "Every 7,500 miles",
      tireRotation: "Every 7,500 miles",
      brakeInspection: "Every 7,500 miles"
    },
    colors: ["Black Raven", "Crystal White Tricoat", "Dark Emerald Fade", "Radiant Silver", "Wave Metallic"],
    technology: ["Super Cruise Hands-Free Driving", "Night Vision", "Augmented Reality Navigation", "AKG Studio 36-Speaker Audio", "Air Ride Adaptive Suspension", "Power Retractable Steps"]
  },
  {
    id: 21,
    name: "Q7",
    brand: "Audi",
    type: "SUV",
    price: 60000,
    image: "https://images.unsplash.com/photo-1615908397724-6dc711db34a7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080",
    fuelType: "Gasoline",
    horsepower: 335,
    topSpeed: 130,
    features: ["Turbocharged V6", "Quattro AWD", "Adaptive Air Suspension", "Virtual Cockpit"],
    engine: {
      type: "Turbocharged V6",
      displacement: "3.0L",
      configuration: "Front-Engine",
      cylinders: 6,
      horsepower: 335,
      torque: "369 lb-ft"
    },
    transmission: {
      type: "8-Speed Tiptronic",
      gears: 8,
      driveType: "Quattro All-Wheel Drive"
    },
    performance: {
      acceleration: "5.7 seconds",
      topSpeed: 130,
      fuelEconomy: "19/23 MPG"
    },
    chassis: {
      suspension: "Adaptive Air Suspension with Damping Control",
      brakes: "Ventilated Disc Brakes",
      wheels: "20-inch 5-Arm Design",
      tires: "285/45 R20"
    },
    interior: {
      seating: "7-Passenger with Valcona Leather",
      infotainment: "MMI Touch with Dual Touchscreens",
      safety: ["Audi Pre Sense", "Adaptive Cruise with Traffic Jam Assist", "360-Degree Cameras", "Side Assist", "8 Airbags"]
    },
    exterior: {
      length: "199.3 in",
      width: "77.5 in",
      height: "68.5 in",
      weight: "4,938 lbs"
    },
    warranty: {
      basic: "4 years / 50,000 miles",
      powertrain: "4 years / 50,000 miles",
      corrosion: "12 years / unlimited miles"
    },
    maintenance: {
      oilChange: "Every 10,000 miles",
      tireRotation: "Every 10,000 miles",
      brakeInspection: "Every 10,000 miles"
    },
    colors: ["Mythos Black", "Glacier White", "Navarra Blue", "Florett Silver", "Dragon Orange"],
    technology: ["Virtual Cockpit Plus", "Top View Camera", "Audi Connect", "Bang & Olufsen 3D Sound", "Wireless Charging", "Mild Hybrid Technology"]
  },
  {
    id: 22,
    name: "Camaro SS",
    brand: "Chevrolet",
    type: "Sports",
    price: 48000,
    image: "https://images.unsplash.com/photo-1584345604325-f5091269a0d1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080",
    fuelType: "Gasoline",
    horsepower: 455,
    topSpeed: 165,
    features: ["V8 Engine", "Magnetic Ride Control", "Launch Control", "Performance Exhaust"],
    engine: {
      type: "Naturally Aspirated V8",
      displacement: "6.2L LT1",
      configuration: "Front-Engine",
      cylinders: 8,
      horsepower: 455,
      torque: "455 lb-ft"
    },
    transmission: {
      type: "6-Speed Manual",
      gears: 6,
      driveType: "Rear-Wheel Drive"
    },
    performance: {
      acceleration: "4.0 seconds",
      topSpeed: 165,
      fuelEconomy: "16/24 MPG"
    },
    chassis: {
      suspension: "Magnetic Ride Control Suspension",
      brakes: "Brembo 4-Piston Front Calipers",
      wheels: "20-inch 5-Split Spoke",
      tires: "245/40 ZR20 (Front), 275/35 ZR20 (Rear)"
    },
    interior: {
      seating: "4-Passenger with Recaro Performance Seats",
      infotainment: "8-inch MyLink Touchscreen",
      safety: ["Rear Vision Camera", "Teen Driver Mode", "Tire Pressure Monitoring", "OnStar", "Front Airbags"]
    },
    exterior: {
      length: "188.3 in",
      width: "74.7 in",
      height: "52.4 in",
      weight: "3,685 lbs"
    },
    warranty: {
      basic: "3 years / 36,000 miles",
      powertrain: "5 years / 60,000 miles",
      corrosion: "6 years / 100,000 miles"
    },
    maintenance: {
      oilChange: "Every 7,500 miles",
      tireRotation: "Every 7,500 miles",
      brakeInspection: "Every 7,500 miles"
    },
    colors: ["Red Hot", "Summit White", "Mosaic Black", "Rapid Blue", "Satin Steel Gray"],
    technology: ["Driver Mode Selector", "Performance Traction Management", "Launch Control", "Line Lock", "No-Lift Shift", "Active Rev Matching"]
  },
  {
    id: 23,
    name: "Challenger SRT Hellcat",
    brand: "Dodge",
    type: "Sports",
    price: 72000,
    image: "https://images.unsplash.com/photo-1606942790567-5783bab8d944?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080",
    fuelType: "Gasoline",
    horsepower: 717,
    topSpeed: 196,
    features: ["Supercharged V8", "Launch Control", "Adaptive Damping Suspension", "Line Lock"],
    engine: {
      type: "Supercharged V8 HEMI",
      displacement: "6.2L",
      configuration: "Front-Engine",
      cylinders: 8,
      horsepower: 717,
      torque: "656 lb-ft"
    },
    transmission: {
      type: "8-Speed Automatic",
      gears: 8,
      driveType: "Rear-Wheel Drive"
    },
    performance: {
      acceleration: "3.6 seconds",
      topSpeed: 196,
      fuelEconomy: "13/22 MPG"
    },
    chassis: {
      suspension: "Bilstein Adaptive Damping Suspension",
      brakes: "Brembo 6-Piston Front / 4-Piston Rear",
      wheels: "20-inch Satin Carbon Aluminum",
      tires: "275/40 ZR20"
    },
    interior: {
      seating: "5-Passenger with Cloth/Alcantara Sport Seats",
      infotainment: "8.4-inch Uconnect Touchscreen",
      safety: ["Blind Spot Monitoring", "Rear Cross Path Detection", "ParkView Rear Backup Camera", "Electronic Stability Control", "Multistage Airbags"]
    },
    exterior: {
      length: "197.9 in",
      width: "75.7 in",
      height: "57.4 in",
      weight: "4,449 lbs"
    },
    warranty: {
      basic: "3 years / 36,000 miles",
      powertrain: "5 years / 60,000 miles",
      corrosion: "5 years / 100,000 miles"
    },
    maintenance: {
      oilChange: "Every 6,000 miles",
      tireRotation: "Every 6,000 miles",
      brakeInspection: "Every 10,000 miles"
    },
    colors: ["TorRed", "Pitch Black", "White Knuckle", "F8 Green", "Go Mango"],
    technology: ["SRT Drive Modes", "Launch Assist", "Launch Control", "Line Lock", "After-Run Chiller", "Performance Pages Display"]
  },
  {
    id: 24,
    name: "Mustang GT",
    brand: "Ford",
    type: "Sports",
    price: 45000,
    image: "https://images.unsplash.com/photo-1616019459068-4cc6dca4d3a1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080",
    fuelType: "Gasoline",
    horsepower: 480,
    topSpeed: 180,
    features: ["V8 Coyote Engine", "MagneRide Damping", "Active Valve Exhaust", "Launch Control"],
    engine: {
      type: "Naturally Aspirated V8 Coyote",
      displacement: "5.0L",
      configuration: "Front-Engine",
      cylinders: 8,
      horsepower: 480,
      torque: "415 lb-ft"
    },
    transmission: {
      type: "6-Speed Manual",
      gears: 6,
      driveType: "Rear-Wheel Drive"
    },
    performance: {
      acceleration: "4.3 seconds",
      topSpeed: 180,
      fuelEconomy: "16/25 MPG"
    },
    chassis: {
      suspension: "MagneRide Damping System",
      brakes: "Brembo 6-Piston Front Calipers",
      wheels: "19-inch Premium Painted Aluminum",
      tires: "255/40 R19 (Front), 275/40 R19 (Rear)"
    },
    interior: {
      seating: "4-Passenger with Cloth Sport Seats",
      infotainment: "13.2-inch SYNC 4 Touchscreen",
      safety: ["Pre-Collision Assist", "Lane-Keeping System", "Blind Spot Information", "Rear Cross-Traffic Alert", "Dual Front Airbags"]
    },
    exterior: {
      length: "188.5 in",
      width: "75.4 in",
      height: "54.4 in",
      weight: "3,825 lbs"
    },
    warranty: {
      basic: "3 years / 36,000 miles",
      powertrain: "5 years / 60,000 miles",
      corrosion: "5 years / unlimited miles"
    },
    maintenance: {
      oilChange: "Every 10,000 miles",
      tireRotation: "Every 7,500 miles",
      brakeInspection: "Every 10,000 miles"
    },
    colors: ["Rapid Red", "Shadow Black", "Oxford White", "Velocity Blue", "Grabber Yellow"],
    technology: ["Selectable Drive Modes", "Launch Control", "Line Lock", "Rev Matching", "Active Valve Performance Exhaust", "Digital Instrument Cluster"]
  },
  {
    id: 25,
    name: "M4 Competition",
    brand: "BMW",
    type: "Sports",
    price: 78000,
    image: "https://images.unsplash.com/photo-1615908397724-6dc711db34a7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080",
    fuelType: "Gasoline",
    horsepower: 503,
    topSpeed: 180,
    features: ["Twin-Turbo Inline-6", "M xDrive AWD", "Adaptive M Suspension", "Carbon Fiber Roof"],
    engine: {
      type: "Twin-Turbocharged Inline-6",
      displacement: "3.0L S58",
      configuration: "Front-Engine",
      cylinders: 6,
      horsepower: 503,
      torque: "479 lb-ft"
    },
    transmission: {
      type: "8-Speed M Steptronic",
      gears: 8,
      driveType: "M xDrive All-Wheel Drive"
    },
    performance: {
      acceleration: "3.8 seconds",
      topSpeed: 180,
      fuelEconomy: "18/25 MPG"
    },
    chassis: {
      suspension: "Adaptive M Suspension with EDC",
      brakes: "M Compound Brakes",
      wheels: "19-inch Front / 20-inch Rear M Double-Spoke",
      tires: "275/35 R19 (Front), 285/30 R20 (Rear)"
    },
    interior: {
      seating: "4-Passenger with M Sport Seats",
      infotainment: "14.9-inch Curved Display with iDrive 8",
      safety: ["Active Driving Assistant Pro", "Parking Assistant Plus", "Surround View", "Lane Departure Warning", "Multiple Airbags"]
    },
    exterior: {
      length: "188.5 in",
      width: "74.3 in",
      height: "55.7 in",
      weight: "3,990 lbs"
    },
    warranty: {
      basic: "4 years / 50,000 miles",
      powertrain: "4 years / 50,000 miles",
      corrosion: "12 years / unlimited miles"
    },
    maintenance: {
      oilChange: "Every 10,000 miles",
      tireRotation: "Every 10,000 miles",
      brakeInspection: "Every 10,000 miles"
    },
    colors: ["São Paulo Yellow", "Toronto Red Metallic", "Brooklyn Grey Metallic", "M Portimao Blue", "Alpine White"],
    technology: ["M Mode Button", "M Traction Control", "Launch Control", "M Drive Professional", "Head-Up Display", "Harman Kardon Surround Sound"]
  }
];

export default function App() {
  const [selectedType, setSelectedType] = useState('All');
  const [selectedFuelType, setSelectedFuelType] = useState('All');
  const [selectedBrand, setSelectedBrand] = useState('All');
  const [priceRange, setPriceRange] = useState<[number, number]>([30000, 500000]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCar, setSelectedCar] = useState<CarData | null>(null);

  const filteredCars = carsData.filter((car) => {
    const matchesType = selectedType === 'All' || car.type === selectedType;
    const matchesFuel = selectedFuelType === 'All' || car.fuelType === selectedFuelType;
    const matchesBrand = selectedBrand === 'All' || car.brand === selectedBrand;
    const matchesPrice = car.price >= priceRange[0] && car.price <= priceRange[1];
    const matchesSearch = car.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         car.brand.toLowerCase().includes(searchQuery.toLowerCase());

    return matchesType && matchesFuel && matchesBrand && matchesPrice && matchesSearch;
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      <header className="bg-white shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center gap-3 mb-4">
            <Car className="w-8 h-8 text-blue-600" />
            <h1 className="text-4xl font-bold text-gray-900">CarFinder</h1>
          </div>
          <p className="text-gray-600">Find your perfect car based on your preferences and needs</p>

          <div className="mt-6 relative">
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search by car name or brand..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-12 pr-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-600"
            />
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          <aside className="lg:col-span-1">
            <FilterSidebar
              selectedType={selectedType}
              setSelectedType={setSelectedType}
              selectedFuelType={selectedFuelType}
              setSelectedFuelType={setSelectedFuelType}
              selectedBrand={selectedBrand}
              setSelectedBrand={setSelectedBrand}
              priceRange={priceRange}
              setPriceRange={setPriceRange}
            />
          </aside>

          <div className="lg:col-span-3">
            <div className="mb-6 flex items-center justify-between">
              <h2 className="text-2xl font-bold text-gray-900">
                {filteredCars.length} {filteredCars.length === 1 ? 'Car' : 'Cars'} Found
              </h2>
            </div>

            {filteredCars.length === 0 ? (
              <div className="bg-white rounded-lg shadow-lg p-12 text-center">
                <Car className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-gray-700 mb-2">No cars found</h3>
                <p className="text-gray-500">Try adjusting your filters to see more results</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {filteredCars.map((car) => (
                  <CarCard key={car.id} {...car} onViewDetails={() => setSelectedCar(car)} />
                ))}
              </div>
            )}
          </div>
        </div>
      </main>

      <footer className="bg-white shadow-md mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 text-center text-gray-600">
          <p>© 2026 CarFinder. Find your dream car today.</p>
        </div>
      </footer>

      {selectedCar && (
        <CarDetailsModal car={selectedCar} onClose={() => setSelectedCar(null)} />
      )}
    </div>
  );
}