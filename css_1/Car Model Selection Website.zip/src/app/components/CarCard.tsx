import { Fuel, Gauge, Settings, Zap } from 'lucide-react';

interface CarCardProps {
  name: string;
  brand: string;
  type: string;
  price: number;
  image: string;
  fuelType: string;
  horsepower: number;
  topSpeed: number;
  features: string[];
  onViewDetails: () => void;
}

export function CarCard({ name, brand, type, price, image, fuelType, horsepower, topSpeed, features, onViewDetails }: CarCardProps) {
  return (
    <div className="bg-white rounded-lg shadow-lg overflow-hidden hover:shadow-xl transition-shadow duration-300">
      <div className="relative h-64 overflow-hidden">
        <img
          src={image}
          alt={name}
          className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
        />
        <div className="absolute top-4 right-4 bg-white px-3 py-1 rounded-full text-sm font-semibold">
          {type}
        </div>
      </div>

      <div className="p-6">
        <div className="mb-4">
          <p className="text-sm text-gray-500">{brand}</p>
          <h3 className="text-2xl font-bold text-gray-900">{name}</h3>
        </div>

        <div className="grid grid-cols-3 gap-3 mb-4 text-sm">
          <div className="flex items-center gap-2">
            <Fuel className="w-4 h-4 text-blue-600" />
            <span className="text-gray-600">{fuelType}</span>
          </div>
          <div className="flex items-center gap-2">
            <Zap className="w-4 h-4 text-orange-600" />
            <span className="text-gray-600">{horsepower} HP</span>
          </div>
          <div className="flex items-center gap-2">
            <Gauge className="w-4 h-4 text-green-600" />
            <span className="text-gray-600">{topSpeed} mph</span>
          </div>
        </div>

        <div className="mb-4">
          <div className="flex items-center gap-2 mb-2">
            <Settings className="w-4 h-4 text-gray-600" />
            <span className="text-sm font-semibold text-gray-700">Key Features:</span>
          </div>
          <ul className="text-sm text-gray-600 space-y-1">
            {features.slice(0, 3).map((feature, index) => (
              <li key={index} className="flex items-start">
                <span className="mr-2">•</span>
                <span>{feature}</span>
              </li>
            ))}
          </ul>
        </div>

        <div className="flex items-center justify-between pt-4 border-t border-gray-200">
          <div>
            <p className="text-sm text-gray-500">Starting at</p>
            <p className="text-2xl font-bold text-blue-600">${price.toLocaleString()}</p>
          </div>
          <button
            onClick={onViewDetails}
            className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg transition-colors duration-200"
          >
            View Details
          </button>
        </div>
      </div>
    </div>
  );
}
