
  # Car Model Selection Website

  This is a code bundle for Car Model Selection Website. The original project is available at https://www.figma.com/design/yU79RmtwBwI8YRNQMSNtQ7/Car-Model-Selection-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  