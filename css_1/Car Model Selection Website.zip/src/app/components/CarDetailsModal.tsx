import { X, Settings, Wrench, Gauge, Zap, Wind, Disc, Cog, Shield, DollarSign, Calendar, Palette } from 'lucide-react';

interface CarDetails {
  name: string;
  brand: string;
  image: string;
  price: number;
  engine: {
    type: string;
    displacement: string;
    configuration: string;
    cylinders: number;
    horsepower: number;
    torque: string;
  };
  transmission: {
    type: string;
    gears: number;
    driveType: string;
  };
  performance: {
    acceleration: string;
    topSpeed: number;
    fuelEconomy: string;
  };
  chassis: {
    suspension: string;
    brakes: string;
    wheels: string;
    tires: string;
  };
  interior: {
    seating: string;
    infotainment: string;
    safety: string[];
  };
  exterior: {
    length: string;
    width: string;
    height: string;
    weight: string;
  };
  warranty: {
    basic: string;
    powertrain: string;
    corrosion: string;
  };
  maintenance: {
    oilChange: string;
    tireRotation: string;
    brakeInspection: string;
  };
  colors: string[];
  technology: string[];
}

interface CarDetailsModalProps {
  car: CarDetails;
  onClose: () => void;
}

export function CarDetailsModal({ car, onClose }: CarDetailsModalProps) {
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-white border-b border-gray-200 p-6 flex items-center justify-between z-10">
          <div>
            <h2 className="text-3xl font-bold text-gray-900">{car.brand} {car.name}</h2>
            <p className="text-xl text-blue-600 font-semibold">${car.price.toLocaleString()}</p>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-full transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="relative h-80">
          <img
            src={car.image}
            alt={car.name}
            className="w-full h-full object-cover"
          />
        </div>

        <div className="p-6 space-y-6">
          <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg p-6">
            <div className="flex items-center gap-2 mb-4">
              <Cog className="w-6 h-6 text-blue-600" />
              <h3 className="text-2xl font-bold text-gray-900">Engine Specifications</h3>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              <div>
                <p className="text-sm text-gray-500">Engine Type</p>
                <p className="font-semibold text-gray-900">{car.engine.type}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Displacement</p>
                <p className="font-semibold text-gray-900">{car.engine.displacement}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Configuration</p>
                <p className="font-semibold text-gray-900">{car.engine.configuration}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Cylinders</p>
                <p className="font-semibold text-gray-900">{car.engine.cylinders}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Horsepower</p>
                <p className="font-semibold text-gray-900">{car.engine.horsepower} HP</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Torque</p>
                <p className="font-semibold text-gray-900">{car.engine.torque}</p>
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-r from-green-50 to-emerald-50 rounded-lg p-6">
            <div className="flex items-center gap-2 mb-4">
              <Settings className="w-6 h-6 text-green-600" />
              <h3 className="text-2xl font-bold text-gray-900">Transmission & Drivetrain</h3>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              <div>
                <p className="text-sm text-gray-500">Transmission Type</p>
                <p className="font-semibold text-gray-900">{car.transmission.type}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Number of Gears</p>
                <p className="font-semibold text-gray-900">{car.transmission.gears}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Drive Type</p>
                <p className="font-semibold text-gray-900">{car.transmission.driveType}</p>
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-r from-orange-50 to-red-50 rounded-lg p-6">
            <div className="flex items-center gap-2 mb-4">
              <Gauge className="w-6 h-6 text-orange-600" />
              <h3 className="text-2xl font-bold text-gray-900">Performance</h3>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              <div>
                <p className="text-sm text-gray-500">0-60 mph</p>
                <p className="font-semibold text-gray-900">{car.performance.acceleration}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Top Speed</p>
                <p className="font-semibold text-gray-900">{car.performance.topSpeed} mph</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Fuel Economy</p>
                <p className="font-semibold text-gray-900">{car.performance.fuelEconomy}</p>
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-r from-purple-50 to-pink-50 rounded-lg p-6">
            <div className="flex items-center gap-2 mb-4">
              <Wrench className="w-6 h-6 text-purple-600" />
              <h3 className="text-2xl font-bold text-gray-900">Chassis & Suspension</h3>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-gray-500">Suspension System</p>
                <p className="font-semibold text-gray-900">{car.chassis.suspension}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Braking System</p>
                <p className="font-semibold text-gray-900">{car.chassis.brakes}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Wheels</p>
                <p className="font-semibold text-gray-900">{car.chassis.wheels}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Tires</p>
                <p className="font-semibold text-gray-900">{car.chassis.tires}</p>
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-r from-cyan-50 to-blue-50 rounded-lg p-6">
            <div className="flex items-center gap-2 mb-4">
              <Wind className="w-6 h-6 text-cyan-600" />
              <h3 className="text-2xl font-bold text-gray-900">Interior Features</h3>
            </div>
            <div className="space-y-3">
              <div>
                <p className="text-sm text-gray-500">Seating</p>
                <p className="font-semibold text-gray-900">{car.interior.seating}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Infotainment System</p>
                <p className="font-semibold text-gray-900">{car.interior.infotainment}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500 mb-2">Safety Features</p>
                <ul className="space-y-1">
                  {car.interior.safety.map((feature, index) => (
                    <li key={index} className="flex items-start">
                      <span className="text-green-600 mr-2">✓</span>
                      <span className="font-medium text-gray-900">{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-r from-gray-50 to-slate-50 rounded-lg p-6">
            <div className="flex items-center gap-2 mb-4">
              <Disc className="w-6 h-6 text-gray-600" />
              <h3 className="text-2xl font-bold text-gray-900">Dimensions & Weight</h3>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div>
                <p className="text-sm text-gray-500">Length</p>
                <p className="font-semibold text-gray-900">{car.exterior.length}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Width</p>
                <p className="font-semibold text-gray-900">{car.exterior.width}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Height</p>
                <p className="font-semibold text-gray-900">{car.exterior.height}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Weight</p>
                <p className="font-semibold text-gray-900">{car.exterior.weight}</p>
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-r from-yellow-50 to-amber-50 rounded-lg p-6">
            <div className="flex items-center gap-2 mb-4">
              <Shield className="w-6 h-6 text-yellow-600" />
              <h3 className="text-2xl font-bold text-gray-900">Warranty Coverage</h3>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <p className="text-sm text-gray-500">Basic Warranty</p>
                <p className="font-semibold text-gray-900">{car.warranty.basic}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Powertrain Warranty</p>
                <p className="font-semibold text-gray-900">{car.warranty.powertrain}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Corrosion Warranty</p>
                <p className="font-semibold text-gray-900">{car.warranty.corrosion}</p>
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-r from-teal-50 to-cyan-50 rounded-lg p-6">
            <div className="flex items-center gap-2 mb-4">
              <Calendar className="w-6 h-6 text-teal-600" />
              <h3 className="text-2xl font-bold text-gray-900">Maintenance Schedule</h3>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <p className="text-sm text-gray-500">Oil Change</p>
                <p className="font-semibold text-gray-900">{car.maintenance.oilChange}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Tire Rotation</p>
                <p className="font-semibold text-gray-900">{car.maintenance.tireRotation}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Brake Inspection</p>
                <p className="font-semibold text-gray-900">{car.maintenance.brakeInspection}</p>
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-r from-pink-50 to-rose-50 rounded-lg p-6">
            <div className="flex items-center gap-2 mb-4">
              <Palette className="w-6 h-6 text-pink-600" />
              <h3 className="text-2xl font-bold text-gray-900">Available Colors</h3>
            </div>
            <div className="flex flex-wrap gap-3">
              {car.colors.map((color, index) => (
                <div
                  key={index}
                  className="px-4 py-2 bg-white rounded-lg shadow-sm border border-gray-200 font-medium text-gray-900"
                >
                  {color}
                </div>
              ))}
            </div>
          </div>

          <div className="bg-gradient-to-r from-indigo-50 to-violet-50 rounded-lg p-6">
            <div className="flex items-center gap-2 mb-4">
              <Zap className="w-6 h-6 text-indigo-600" />
              <h3 className="text-2xl font-bold text-gray-900">Advanced Technology</h3>
            </div>
            <ul className="grid grid-cols-1 md:grid-cols-2 gap-2">
              {car.technology.map((tech, index) => (
                <li key={index} className="flex items-start">
                  <span className="text-indigo-600 mr-2">✓</span>
                  <span className="font-medium text-gray-900">{tech}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="p-6 border-t border-gray-200 bg-gray-50">
          <button
            onClick={onClose}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-lg font-semibold transition-colors"
          >
            Close Details
          </button>
        </div>
      </div>
    </div>
  );
}
